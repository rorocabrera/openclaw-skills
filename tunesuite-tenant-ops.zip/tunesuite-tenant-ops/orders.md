# TuneSuite Orders Management

> ⚠️ **IMPORTANT**: This skill provides the ONLY interface to TuneSuite. Agents using this skill must use these API endpoints exclusively. Do NOT use direct database access, file system access to TuneSuite servers, or any other method. All data access must go through the API defined below.

> 📡 **API Endpoint**: `https://api.tunersuite.com/api` — This is the multi-tenant API that serves ALL TuneSuite tenants. All endpoints below are relative to this base URL.

> 🔐 **Authentication Required**: See [./SKILL.md](./SKILL.md) for authentication setup (tenant resolution, login, token handling).

---

## When to Use

- "List my recent orders"
- "Search for order by email john@example.com"
- "Show me details of order abc-123"
- "What services were selected on order X?"
- "What vehicle is on order X?"
- "Download the original file from order X"
- "Upload a modified file to order X"
- "Change order status to in_progress"
- "Assign technician to order"
- "Show order history for order X"
- "What files are attached to order X?"
- "Connect to tenant mycompany"

## Capability Preflight

Before order operations, ensure these capabilities are `true`:

- `orders.list`, `orders.view`, `orders.search` for read operations
- `orders.updateStatus`, `orders.assignTechnician`, `orders.updateServices`, `orders.uploadFile`, `orders.deleteFile` for mutations

Check example:

```bash
echo "$TUNESUITE_CAPABILITIES" | jq -r '.capabilities["orders.updateStatus"]'
```

---

## 1 — List Orders (with pagination and filtering)

```bash
curl -s "$TUNESUITE_API_URL/tenant-orders?page=1&limit=20" \
  -H "Authorization: Bearer $TUNESUITE_TOKEN" \
  -H "x-tenant-id: $TUNESUITE_TENANT_ID" | jq
```

### Available Query Parameters

| Parameter | Type | Description |
|-----------|------|-------------|
| `page` | number | Page number (starts at 1) |
| `limit` | number | Items per page (default 20, max 100) |
| `unifiedSearch` | string | Search across order ID, client email, client name, model name, comments |
| `orderId` | string | Filter by exact or partial order UUID |
| `clientEmail` | string | Filter by client email |
| `technicianId` | string | Filter by assigned technician UUID |
| `status[]` | string | Filter by status (can repeat for multiple). Values: `created`, `pending_assignment`, `assigned`, `in_progress`, `reviewing`, `waiting_credits`, `completed`, `cancelled`, `refunded` |
| `modelName` | string | Filter by ECU model name |
| `vehicleTypeId` | string | Filter by vehicle type UUID |
| `brandId` | string | Filter by brand UUID |
| `sortOrder` | string | `ASC` or `DESC` (by creation date) |

### Examples

**Search by client email:**
```bash
curl -s "$TUNESUITE_API_URL/tenant-orders?unifiedSearch=john@example.com&page=1&limit=10" \
  -H "Authorization: Bearer $TUNESUITE_TOKEN" \
  -H "x-tenant-id: $TUNESUITE_TENANT_ID" | jq
```

**Search by client name:**
```bash
curl -s "$TUNESUITE_API_URL/tenant-orders?unifiedSearch=John%20Smith&page=1&limit=10" \
  -H "Authorization: Bearer $TUNESUITE_TOKEN" \
  -H "x-tenant-id: $TUNESUITE_TENANT_ID" | jq
```

**Search by order ID (partial UUID works with 2+ characters):**
```bash
curl -s "$TUNESUITE_API_URL/tenant-orders?unifiedSearch=abc123&page=1&limit=10" \
  -H "Authorization: Bearer $TUNESUITE_TOKEN" \
  -H "x-tenant-id: $TUNESUITE_TENANT_ID" | jq
```

**Filter by multiple statuses:**
```bash
curl -s "$TUNESUITE_API_URL/tenant-orders?status[]=in_progress&status[]=assigned&page=1&limit=20" \
  -H "Authorization: Bearer $TUNESUITE_TOKEN" \
  -H "x-tenant-id: $TUNESUITE_TENANT_ID" | jq
```

**Filter by status and sort descending:**
```bash
curl -s "$TUNESUITE_API_URL/tenant-orders?status[]=completed&sortOrder=DESC&page=1&limit=20" \
  -H "Authorization: Bearer $TUNESUITE_TOKEN" \
  -H "x-tenant-id: $TUNESUITE_TENANT_ID" | jq
```

### Response Format

```json
{
  "items": [
    {
      "id": "uuid",
      "status": "in_progress",
      "totalPrice": "150.00",
      "createdAt": "2025-01-15T10:30:00Z",
      "updatedAt": "2025-01-15T12:00:00Z",
      "client": { "id": "uuid", "email": "client@example.com", "profile": { "name": "Client Name" } },
      "technician": { "id": "uuid", "email": "tech@example.com" },
      "model": { "id": "uuid", "name": "BMW N55" },
      "vehicleType": { "id": "uuid", "name": "Car" },
      "services": [ { "id": "uuid", "service": { "name": "Stage 1" }, "price": "100.00" } ],
      "vehicleDetails": { "brand": "BMW", "model": "335i", "year": 2015, "vin": "..." },
      "files": [ { "id": "uuid", "filename": "original.bin", "isOriginal": true } ],
      "quotationSnapshot": { "breakdown": { "finalTotal": 150, "services": [...] } }
    }
  ],
  "meta": { "currentPage": 1, "itemsPerPage": 20, "totalItems": 45, "totalPages": 3 }
}
```

### Presenting Order Lists to the User

When showing a list of orders, present a clean summary table with these columns:
- **Order ID** (first 8 characters of UUID)
- **Client** (name + email)
- **Status**
- **Model** (ECU model name)
- **Vehicle** (brand + model + year)
- **Total Price**
- **Created** (date only)

---

## 2 — Get Order Details

```bash
curl -s "$TUNESUITE_API_URL/tenant-orders/ORDER_ID_HERE" \
  -H "Authorization: Bearer $TUNESUITE_TOKEN" \
  -H "x-tenant-id: $TUNESUITE_TENANT_ID" | jq
```

This returns the full order with all relations: client, technician, model, services, vehicleDetails, files, history, and quotationSnapshot.

### Key Fields to Present

**Order Info:**
- `id`, `status`, `totalPrice`, `createdAt`, `updatedAt`

**Client Info:**
- `client.email`, `client.profile.name`, `client.profile.phone`

**Technician:**
- `technician.email`, `technician.profile.name` (null if unassigned)

**Vehicle Details** (`vehicleDetails`):
- `brand`, `model`, `year`, `power`, `displacement`, `vin`, `comments`, `additionalInfo`

**Services Selected** (`services` array):
- Each item has `service.name` and `price`

**Quotation Snapshot** (`quotationSnapshot`):
- `breakdown.basePrice` — base price before multipliers
- `breakdown.vehicleMultiplier` — vehicle type multiplier
- `breakdown.finalTotal` — final price charged
- `breakdown.services[]` — per-service pricing detail

**Files** (`files` array):
- `id`, `filename`, `isOriginal`, `isVisibleToClient`, `createdAt`
- `internalNotes`, `clientComment`
- `ecuDecodeMetadata` — decoded ECU info (if available)

**Order History** (`history` array):
- `changeDescription` — type of change (see list below)
- `changeComment` — user notes on the change
- `previousValues`, `newValues` — JSONB snapshots of what changed
- `changedBy.email` — who made the change
- `createdAt` — when the change happened

**History Change Types:**
`VEHICLE_DETAILS`, `SERVICES`, `MODEL`, `FILE_VISIBILITY`, `ORDER_STATUS`, `FILE_UPLOAD`, `FILE_DELETE`, `FILE_UPDATE`, `FILE_DOWNLOAD`, `FILE_ENCRYPTION`, `FILE_DECRYPTION`, `FILE_ACCESS`, `TECH_ASSIGNMENT`, `REFUND`

---

## 3 — Get Orders for a Specific User

First find the user ID by searching orders:
```bash
curl -s "$TUNESUITE_API_URL/tenant-orders?unifiedSearch=user@email.com&page=1&limit=1" \
  -H "Authorization: Bearer $TUNESUITE_TOKEN" \
  -H "x-tenant-id: $TUNESUITE_TENANT_ID" | jq '.items[0].client.id'
```

Then fetch all their orders:
```bash
curl -s "$TUNESUITE_API_URL/tenant-orders/user/USER_ID_HERE?page=1&limit=20" \
  -H "Authorization: Bearer $TUNESUITE_TOKEN" \
  -H "x-tenant-id: $TUNESUITE_TENANT_ID" | jq
```

Supports the same filtering parameters as the main list endpoint (`status[]`, `modelName`, `sortOrder`, etc.).

---

## 4 — Get New Orders Count

```bash
curl -s "$TUNESUITE_API_URL/tenant-orders/new-count" \
  -H "Authorization: Bearer $TUNESUITE_TOKEN" \
  -H "x-tenant-id: $TUNESUITE_TENANT_ID" | jq
```

Returns a number representing orders with `created` status.

---

## 5 — Update Order Status

```bash
curl -s -X PATCH "$TUNESUITE_API_URL/tenant-orders/ORDER_ID_HERE/status" \
  -H "Authorization: Bearer $TUNESUITE_TOKEN" \
  -H "x-tenant-id: $TUNESUITE_TENANT_ID" \
  -H "Content-Type: application/json" \
  -d '{"status": "in_progress", "comment": "Optional reason for status change"}' | jq
```

### Valid Status Transitions

| Current Status | Can Transition To |
|---------------|-------------------|
| `created` | `pending_assignment`, `in_progress`, `cancelled` |
| `pending_assignment` | `assigned`, `in_progress`, `cancelled` |
| `assigned` | `in_progress`, `cancelled` |
| `in_progress` | `reviewing`, `completed`, `waiting_credits`, `cancelled` |
| `reviewing` | `in_progress`, `completed`, `waiting_credits` |
| `waiting_credits` | `in_progress`, `completed`, `cancelled` |
| `completed` | `refunded` |

**IMPORTANT:** Always confirm with the user before changing status. Status changes trigger notifications and credit operations.

---

## 6 — Assign Technician

```bash
curl -s -X PATCH "$TUNESUITE_API_URL/tenant-orders/ORDER_ID_HERE/assign-technician" \
  -H "Authorization: Bearer $TUNESUITE_TOKEN" \
  -H "x-tenant-id: $TUNESUITE_TENANT_ID" \
  -H "Content-Type: application/json" \
  -d '{"technicianEmail": "tech@example.com", "comment": "Optional assignment comment"}' | jq
```

**Tip:** To find technicians, list all users and look for those with `technician` in their roles:
```bash
curl -s "$TUNESUITE_API_URL/users" \
  -H "Authorization: Bearer $TUNESUITE_TOKEN" \
  -H "x-tenant-id: $TUNESUITE_TENANT_ID" | jq '.items[] | select(.roles | contains(["technician"])) | {email, profile}'
```

---

## 7 — Update Vehicle Details

```bash
curl -s -X PATCH "$TUNESUITE_API_URL/tenant-orders/ORDER_ID_HERE/vehicle-details" \
  -H "Authorization: Bearer $TUNESUITE_TOKEN" \
  -H "x-tenant-id: $TUNESUITE_TENANT_ID" \
  -H "Content-Type: application/json" \
  -d '{
    "userEmail": "client@example.com",
    "vehicleDetails": {
      "brand": "BMW",
      "model": "335i",
      "year": 2015,
      "power": 306,
      "displacement": "2979cc",
      "vin": "WBAXXXXXXXXXXXXXX",
      "comments": "Updated info"
    },
    "changeReason": "Client provided corrected details"
  }' | jq
```

All fields in `vehicleDetails` are optional — only include the fields you want to change. The `userEmail` is the client's email (order owner). `changeReason` is optional but recommended for audit trail.

---

## 8 — Update Order Services (Change Selected Services)

```bash
curl -s -X PATCH "$TUNESUITE_API_URL/tenant-orders/ORDER_ID_HERE/services" \
  -H "Authorization: Bearer $TUNESUITE_TOKEN" \
  -H "x-tenant-id: $TUNESUITE_TENANT_ID" \
  -H "Content-Type: application/json" \
  -d '{
    "userEmail": "client@example.com",
    "newQuotation": {
      "modelId": "model-uuid",
      "services": ["service-uuid-1", "service-uuid-2"],
      "price": 200,
      "currency": "EUR",
      "breakdown": {
        "services": [
          { "amount": 100, "isSingle": false, "serviceId": "service-uuid-1", "percentage": "100", "serviceName": "Stage 1" },
          { "amount": 100, "isSingle": false, "serviceId": "service-uuid-2", "percentage": "100", "serviceName": "DPF Delete" }
        ],
        "basePrice": 200,
        "finalTotal": 200,
        "vehicleMultiplier": "1"
      }
    },
    "changeReason": "Client requested additional service"
  }' | jq
```

**WARNING:** Changing services recalculates the order price and may deduct or refund credits. Always confirm with the user first.

---

## 9 — Change ECU Model

```bash
curl -s -X PATCH "$TUNESUITE_API_URL/tenant-orders/ORDER_ID_HERE/model" \
  -H "Authorization: Bearer $TUNESUITE_TOKEN" \
  -H "x-tenant-id: $TUNESUITE_TENANT_ID" \
  -H "Content-Type: application/json" \
  -d '{
    "modelId": "new-model-uuid",
    "userEmail": "client@example.com",
    "changeReason": "Wrong model selected initially"
  }' | jq
```

---

## 10 — Download Files

### Download Original File (with optional decryption)

**Without decryption:**
```bash
curl -s "$TUNESUITE_API_URL/tenant-orders/ORDER_ID/files/FILE_ID/download-original" \
  -H "Authorization: Bearer $TUNESUITE_TOKEN" \
  -H "x-tenant-id: $TUNESUITE_TENANT_ID" \
  -o downloaded_file.bin
```

**With decryption (for Alientech/MMS encrypted files):**
```bash
curl -s "$TUNESUITE_API_URL/tenant-orders/ORDER_ID/files/FILE_ID/download-original?decrypt=true" \
  -H "Authorization: Bearer $TUNESUITE_TOKEN" \
  -H "x-tenant-id: $TUNESUITE_TENANT_ID" \
  -o decrypted_file.bin
```

Decryption requires the tenant to have valid Alientech or Magic Motorsport API keys configured.

### Listing Files for an Order

Files are included in the order detail response. To see just the files:
```bash
curl -s "$TUNESUITE_API_URL/tenant-orders/ORDER_ID_HERE" \
  -H "Authorization: Bearer $TUNESUITE_TOKEN" \
  -H "x-tenant-id: $TUNESUITE_TENANT_ID" | jq '.files[] | {id, filename, isOriginal, isVisibleToClient, createdAt, internalNotes, clientComment}'
```

---

## 11 — Upload Modified File

```bash
curl -s -X POST "$TUNESUITE_API_URL/tenant-orders/ORDER_ID_HERE/files?encrypt=false" \
  -H "Authorization: Bearer $TUNESUITE_TOKEN" \
  -H "x-tenant-id: $TUNESUITE_TENANT_ID" \
  -F "file=@/path/to/modified_file.bin" | jq
```

### With encryption (auto-encrypts for the client's ECU tool):
```bash
curl -s -X POST "$TUNESUITE_API_URL/tenant-orders/ORDER_ID_HERE/files?encrypt=true" \
  -H "Authorization: Bearer $TUNESUITE_TOKEN" \
  -H "x-tenant-id: $TUNESUITE_TENANT_ID" \
  -F "file=@/path/to/modified_file.bin" | jq
```

### For Magic Motorsport tools (requires memoryType):
```bash
curl -s -X POST "$TUNESUITE_API_URL/tenant-orders/ORDER_ID_HERE/files?encrypt=true" \
  -H "Authorization: Bearer $TUNESUITE_TOKEN" \
  -H "x-tenant-id: $TUNESUITE_TENANT_ID" \
  -F "file=@/path/to/modified_file.bin" \
  -F "memoryType=int_flash" | jq
```

Valid `memoryType` values: `int_flash`, `ext_flash`, `int_eeprom`, `ext_eeprom`, `maps`, `full_dump`

### Response:
```json
{
  "orderFile": {
    "id": "uuid",
    "filename": "modified_file.bin",
    "isOriginal": false,
    "isVisibleToClient": true
  },
  "encryptionStatus": "success" | "skipped" | "failed"
}
```

---

## 12 — Update File Metadata

```bash
curl -s -X PATCH "$TUNESUITE_API_URL/tenant-orders/ORDER_ID/files/FILE_ID" \
  -H "Authorization: Bearer $TUNESUITE_TOKEN" \
  -H "x-tenant-id: $TUNESUITE_TENANT_ID" \
  -H "Content-Type: application/json" \
  -d '{
    "isVisibleToClient": true,
    "internalNotes": "Modified with Stage 1 map",
    "clientComment": "Stage 1 tune applied"
  }' | jq
```

---

## 13 — Rename File

```bash
curl -s -X PATCH "$TUNESUITE_API_URL/tenant-orders/ORDER_ID/files/FILE_ID/rename" \
  -H "Authorization: Bearer $TUNESUITE_TOKEN" \
  -H "x-tenant-id: $TUNESUITE_TENANT_ID" \
  -H "Content-Type: application/json" \
  -d '{"newFileName": "BMW_335i_Stage1_Modified.bin"}' | jq
```

---

## 14 — Delete Modified File

```bash
curl -s -X DELETE "$TUNESUITE_API_URL/tenant-orders/ORDER_ID/files/FILE_ID" \
  -H "Authorization: Bearer $TUNESUITE_TOKEN" \
  -H "x-tenant-id: $TUNESUITE_TENANT_ID" | jq
```

**Note:** Only modified files (isOriginal = false) can be deleted. Original uploads cannot be deleted.

---

## 15 — Search by VIN (Public Endpoint)

This endpoint is public and does not require authentication:
```bash
curl -s "$TUNESUITE_API_URL/orders/public/by-vin/WBAXXXXXXXXXXXXXX" | jq
```

Returns completed orders matching the VIN.

---

## Order Status Reference

| Status | Meaning |
|--------|---------|
| `created` | New order, awaiting processing |
| `pending_assignment` | Needs technician assignment |
| `assigned` | Technician assigned, not yet started |
| `in_progress` | Technician actively working |
| `reviewing` | Work done, under review |
| `waiting_credits` | Client needs to add credits |
| `completed` | Finished and delivered |
| `cancelled` | Order cancelled |
| `refunded` | Credits refunded after completion |

---

## Tips for the Agent

1. **Always authenticate first** before any operation. Store the token in `$TUNESUITE_TOKEN`.
2. **ALWAYS include x-tenant-id header** in ALL requests after authentication — even after login, the API requires it on every call.
3. **Use `unifiedSearch`** for flexible searching — it covers order ID, email, name, model name, and comments simultaneously.
4. **Present data clearly** — format order lists as tables and order details as structured sections.
5. **Confirm destructive actions** — always ask the user before changing status, updating services (affects credits), or deleting files.
6. **Handle pagination** — check `meta.totalPages` and inform the user if there are more pages.
7. **Token expiry** — instance tokens last ~4 hours. Prefer `/auth/refresh-token` before re-login.
8. **File downloads** — binary files are streamed. Use `-o filename` to save them.
9. **Encryption** — only use `encrypt=true` or `decrypt=true` when the tenant has valid tool API keys configured.
10. **Finding technicians** — use `GET /users` and filter by `technician` role.
11. **429 handling** — if rate limited, retry with exponential backoff (`1s`, `2s`, `4s`, `8s`, jitter).
